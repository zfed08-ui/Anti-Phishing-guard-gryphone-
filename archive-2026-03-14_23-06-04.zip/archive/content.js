/*
 * content.js
 * Контент-скрипт для анализа страницы и мягкого предупреждения пользователя.
 */

const ANALYSIS_DELAY_MS = 2000;
const OVERLAY_ID = 'anti-phishing-soft-warning-overlay';
const STYLE_ID = 'anti-phishing-soft-warning-style';

/**
 * Нормализация URL в том же формате, что и в background.
 * @param {string} inputUrl
 * @returns {string}
 */
function normalizeUrl(inputUrl) {
  if (!inputUrl || typeof inputUrl !== 'string') {
    return '';
  }

  let value = inputUrl.trim().toLowerCase();
  value = value.replace(/^https?:\/\//, '');
  value = value.replace(/^www\./, '');
  value = value.replace(/\/$/, '');

  return value;
}

/**
 * Проверяет URL на признаки подозрительности.
 * @param {string} url
 * @returns {boolean}
 */
function isSuspiciousUrl(url) {
  try {
    const parsed = new URL(url);
    const hostname = parsed.hostname.toLowerCase();
    const parts = hostname.split('.').filter(Boolean);
    const tld = parts.length > 0 ? `.${parts[parts.length - 1]}` : '';

    const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
    const hasIp = ipRegex.test(hostname);
    const isLong = url.length > 50;
    const hasTooManySubdomains = parts.length > 4;
    const suspiciousTlds = new Set(['.xyz', '.top', '.club', '.work', '.date', '.loan', '.bid']);
    const hasSuspiciousTld = suspiciousTlds.has(tld);

    return hasIp || isLong || hasTooManySubdomains || hasSuspiciousTld;
  } catch {
    return false;
  }
}

/**
 * Проверяет наличие внешних форм (домен action отличается от текущего).
 * @returns {boolean}
 */
function hasExternalForms() {
  const forms = Array.from(document.querySelectorAll('form[action]'));

  for (const form of forms) {
    const action = form.getAttribute('action');
    if (!action) {
      continue;
    }

    try {
      const resolved = new URL(action, location.href);
      if (resolved.origin !== location.origin) {
        return true;
      }
    } catch {
      continue;
    }
  }

  return false;
}

/**
 * Добавляет стили оверлея один раз.
 */
function injectOverlayStyles() {
  if (document.getElementById(STYLE_ID)) {
    return;
  }

  const style = document.createElement('style');
  style.id = STYLE_ID;
  style.textContent = `
    #${OVERLAY_ID} {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      z-index: 2147483647;
      background: rgba(12, 16, 28, 0.78);
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: Arial, sans-serif;
      color: #ffffff;
      box-sizing: border-box;
      padding: 16px;
    }

    #${OVERLAY_ID} .apg-card {
      max-width: 520px;
      width: 100%;
      background: #1f2937;
      border: 1px solid #ef4444;
      border-radius: 12px;
      box-shadow: 0 14px 40px rgba(0, 0, 0, 0.45);
      padding: 20px;
      line-height: 1.45;
    }

    #${OVERLAY_ID} .apg-title {
      margin: 0 0 10px;
      font-size: 20px;
      color: #fca5a5;
    }

    #${OVERLAY_ID} .apg-url {
      margin: 10px 0;
      word-break: break-all;
      color: #e5e7eb;
      font-size: 13px;
      opacity: 0.95;
    }

    #${OVERLAY_ID} .apg-score {
      margin: 0 0 16px;
      color: #fecaca;
      font-size: 14px;
    }

    #${OVERLAY_ID} .apg-actions {
      display: flex;
      gap: 10px;
      justify-content: flex-end;
      flex-wrap: wrap;
    }

    #${OVERLAY_ID} .apg-btn {
      border: 0;
      border-radius: 8px;
      padding: 10px 14px;
      font-size: 14px;
      cursor: pointer;
    }

    #${OVERLAY_ID} .apg-btn-close {
      background: #ef4444;
      color: #fff;
    }

    #${OVERLAY_ID} .apg-btn-continue {
      background: #374151;
      color: #fff;
    }
  `;

  document.documentElement.appendChild(style);
}

/**
 * Показывает мягкое предупреждение с кнопками.
 * "Продолжить" добавляет текущий URL в session-хранилище, чтобы не предупреждать повторно в рамках сессии.
 *
 * @param {string} url
 * @param {number} score
 */
async function showSoftWarning(url, score) {
  const sessionKey = `session_${normalizeUrl(url)}`;

  try {
    const sessionData = await chrome.storage.session.get([sessionKey]);
    if (sessionData[sessionKey]) {
      return;
    }
  } catch (error) {
    console.error('[Anti-Phishing Guard] Ошибка чтения storage.session:', error);
  }

  const existingOverlay = document.getElementById(OVERLAY_ID);
  if (existingOverlay) {
    return;
  }

  injectOverlayStyles();

  const overlay = document.createElement('div');
  overlay.id = OVERLAY_ID;

  const card = document.createElement('div');
  card.className = 'apg-card';

  const title = document.createElement('h2');
  title.className = 'apg-title';
  title.textContent = 'Возможный фишинг';

  const description = document.createElement('p');
  description.textContent = 'Обнаружены подозрительные признаки на текущей странице. Будьте осторожны при вводе данных.';

  const urlNode = document.createElement('p');
  urlNode.className = 'apg-url';
  urlNode.textContent = `URL: ${url}`;

  const scoreNode = document.createElement('p');
  scoreNode.className = 'apg-score';
  scoreNode.textContent = `Риск-оценка: ${score}`;

  const actions = document.createElement('div');
  actions.className = 'apg-actions';

  const closeButton = document.createElement('button');
  closeButton.className = 'apg-btn apg-btn-close';
  closeButton.type = 'button';
  closeButton.textContent = 'Закрыть';

  const continueButton = document.createElement('button');
  continueButton.className = 'apg-btn apg-btn-continue';
  continueButton.type = 'button';
  continueButton.textContent = 'Продолжить';

  closeButton.addEventListener('click', () => {
    overlay.remove();
  });

  continueButton.addEventListener('click', async () => {
    try {
      await chrome.storage.session.set({
        [sessionKey]: true
      });
    } catch (error) {
      console.error('[Anti-Phishing Guard] Ошибка записи storage.session:', error);
    }

    overlay.remove();
  });

  actions.append(closeButton, continueButton);
  card.append(title, description, urlNode, scoreNode, actions);
  overlay.appendChild(card);
  document.documentElement.appendChild(overlay);
}

/**
 * Собирает признаки страницы и отправляет в background на анализ.
 */
async function analyzeCurrentPage() {
  try {
    const features = {
      password: document.querySelectorAll('input[type="password"]').length > 0,
      iframe: document.querySelectorAll('iframe').length > 0,
      externalForms: hasExternalForms(),
      suspiciousUrl: isSuspiciousUrl(location.href)
    };

    await chrome.runtime.sendMessage({
      type: 'PAGE_ANALYSIS',
      features,
      url: location.href
    });
  } catch (error) {
    console.error('[Anti-Phishing Guard] Ошибка анализа страницы:', error);
  }
}

/**
 * Обработчик сообщений от background.
 * @param {any} message
 */
function onRuntimeMessage(message) {
  if (!message || message.type !== 'SHOWSOFTWARNING') {
    return;
  }

  void showSoftWarning(message.url || location.href, Number(message.score) || 0);
}

chrome.runtime.onMessage.addListener(onRuntimeMessage);
window.addEventListener('beforeunload', () => {
  try {
    chrome.runtime.onMessage.removeListener(onRuntimeMessage);
  } catch {
    // Игнорируем ошибки очистки.
  }
});

setTimeout(() => {
  void analyzeCurrentPage();
}, ANALYSIS_DELAY_MS);