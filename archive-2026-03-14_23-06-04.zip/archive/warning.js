/*
 * warning.js
 * Логика страницы предупреждения о фишинге.
 */

/**
 * Достаёт URL из query-параметра ?url=...
 * @returns {string}
 */
function getTargetUrlFromQuery() {
  const params = new URLSearchParams(window.location.search);
  return params.get('url') || '';
}

/**
 * Безопасно выводит URL в DOM как текст.
 * @param {string} url
 */
function renderTargetUrl(url) {
  const urlNode = document.getElementById('target-url');
  if (!urlNode) {
    return;
  }

  urlNode.textContent = url || 'Не удалось определить URL';
}

/**
 * Возврат назад: если есть история — history.back(),
 * иначе закрытие текущей вкладки.
 */
async function handleGoBack() {
  if (window.history.length > 1) {
    window.history.back();
    return;
  }

  try {
    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (activeTab?.id) {
      await chrome.tabs.remove(activeTab.id);
    }
  } catch (error) {
    console.error('[Anti-Phishing Guard] Ошибка закрытия вкладки:', error);
  }
}

/**
 * Переход на исходный URL.
 * @param {string} url
 */
function handleProceed(url) {
  if (!url) {
    return;
  }

  window.location.href = url;
}

function initWarningPage() {
  const targetUrl = getTargetUrlFromQuery();
  renderTargetUrl(targetUrl);

  const goBackButton = document.getElementById('go-back-btn');
  const proceedButton = document.getElementById('proceed-btn');

  const onBackClick = () => {
    void handleGoBack();
  };

  const onProceedClick = () => {
    handleProceed(targetUrl);
  };

  goBackButton?.addEventListener('click', onBackClick);
  proceedButton?.addEventListener('click', onProceedClick);

  window.addEventListener(
    'unload',
    () => {
      goBackButton?.removeEventListener('click', onBackClick);
      proceedButton?.removeEventListener('click', onProceedClick);
    },
    { once: true }
  );
}

document.addEventListener('DOMContentLoaded', initWarningPage);