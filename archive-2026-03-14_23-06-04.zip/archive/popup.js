/*
 * popup.js
 * Логика popup-окна: отображение статуса и ручное обновление фишинг-списка.
 */

/**
 * Форматирует дату обновления для UI.
 * @param {string | null | undefined} isoDate
 * @returns {string}
 */
function formatLastUpdate(isoDate) {
  if (!isoDate) {
    return 'Никогда';
  }

  const date = new Date(isoDate);
  if (Number.isNaN(date.getTime())) {
    return 'Неверный формат даты';
  }

  return date.toLocaleString();
}

/**
 * Обновляет UI-статус данными из background.
 * @param {{enabled:boolean, listCount:number, lastUpdate:string | null}} status
 */
function renderStatus(status) {
  const enabledNode = document.getElementById('status-enabled');
  const countNode = document.getElementById('status-count');
  const updatedNode = document.getElementById('status-updated');

  if (enabledNode) {
    enabledNode.textContent = status?.enabled ? 'Активна' : 'Отключена';
  }

  if (countNode) {
    countNode.textContent = Number.isFinite(status?.listCount) ? String(status.listCount) : '0';
  }

  if (updatedNode) {
    updatedNode.textContent = formatLastUpdate(status?.lastUpdate);
  }
}

/**
 * Пишет служебное сообщение в popup.
 * @param {string} text
 * @param {'normal' | 'error'} type
 */
function setMessage(text, type = 'normal') {
  const node = document.getElementById('status-message');
  if (!node) {
    return;
  }

  node.textContent = text;
  node.classList.toggle('is-error', type === 'error');
}

/**
 * Запрашивает текущий статус у background.
 */
async function fetchStatus() {
  try {
    const response = await chrome.runtime.sendMessage({ type: 'GETSTATUS' });
    if (!response?.ok || !response.status) {
      throw new Error(response?.error || 'Не удалось получить статус');
    }

    renderStatus(response.status);
    setMessage('');
  } catch (error) {
    console.error('[Anti-Phishing Guard] Ошибка GETSTATUS:', error);
    setMessage('Ошибка загрузки статуса.', 'error');
  }
}

/**
 * Запускает ручное обновление OpenPhish и обновляет UI.
 */
async function manualUpdate() {
  const button = document.getElementById('manual-update-btn');

  if (button) {
    button.disabled = true;
    button.textContent = 'Обновление...';
  }

  setMessage('Обновляю список...');

  try {
    const response = await chrome.runtime.sendMessage({ type: 'MANUALUPDATE' });
    if (!response?.ok || !response.status) {
      throw new Error(response?.error || 'Ошибка ручного обновления');
    }

    renderStatus(response.status);
    setMessage('Список успешно обновлён.');
  } catch (error) {
    console.error('[Anti-Phishing Guard] Ошибка MANUALUPDATE:', error);
    setMessage('Не удалось обновить список.', 'error');
  } finally {
    if (button) {
      button.disabled = false;
      button.textContent = 'Обновить список';
    }
  }
}

function initPopup() {
  const button = document.getElementById('manual-update-btn');

  const onManualUpdateClick = () => {
    void manualUpdate();
  };

  button?.addEventListener('click', onManualUpdateClick);

  window.addEventListener(
    'unload',
    () => {
      button?.removeEventListener('click', onManualUpdateClick);
    },
    { once: true }
  );

  void fetchStatus();
}

document.addEventListener('DOMContentLoaded', initPopup);