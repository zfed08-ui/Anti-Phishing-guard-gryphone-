/*
 * background.js
 * Фоновый Service Worker для Chrome Extension (Manifest V3).
 * Отвечает за:
 * 1) загрузку фида OpenPhish,
 * 2) хранение и кэширование списка фишинговых URL,
 * 3) блокировку/редирект на warning.html,
 * 4) обработку сообщений от content/popup.
 */

const OPENPHISH_FEED_URL = 'https://openphish.com/feed.txt';
const UPDATE_ALARM_NAME = 'openphish_update_alarm';
const UPDATE_INTERVAL_MINUTES = 60;

const STORAGE_KEYS = {
  PHISH_LIST: 'phishList',
  LAST_UPDATE: 'lastUpdate'
};

/**
 * Кэш в памяти Service Worker для быстрой проверки.
 * Обновляется при старте и после каждой успешной синхронизации.
 */
let phishSet = new Set();

/**
 * Нормализует URL для консистентного сравнения.
 * - убирает протокол (http/https),
 * - убирает префикс www.,
 * - приводит к нижнему регистру,
 * - обрезает хвостовой слэш.
 *
 * @param {string} inputUrl
 * @returns {string}
 */
function normalizeUrl(inputUrl) {
  if (!inputUrl || typeof inputUrl !== 'string') {
    return '';
  }

  let value = inputUrl.trim().toLowerCase();
  value = value.replace(/^https?:\/\//, '');
  value = value.replace(/^www\./, '');
  value = value.replace(/\/$/, '');

  return value;
}

/**
 * Безопасный лог ошибок.
 * @param {string} context
 * @param {unknown} error
 */
function logError(context, error) {
  console.error(`[Anti-Phishing Guard] ${context}:`, error);
}

/**
 * Загружает список фишинговых URL из storage.local в кэш.
 */
async function loadPhishSetFromStorage() {
  try {
    const data = await chrome.storage.local.get([STORAGE_KEYS.PHISH_LIST]);
    const list = Array.isArray(data[STORAGE_KEYS.PHISH_LIST]) ? data[STORAGE_KEYS.PHISH_LIST] : [];
    phishSet = new Set(list);
  } catch (error) {
    logError('Ошибка загрузки списка из storage.local', error);
  }
}

/**
 * Скачивает feed.txt OpenPhish, нормализует и сохраняет в storage.local.
 */
async function updateOpenPhishList() {
  try {
    const response = await fetch(OPENPHISH_FEED_URL, {
      method: 'GET',
      cache: 'no-store'
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const text = await response.text();
    const normalizedEntries = text
      .split('\n')
      .map((line) => normalizeUrl(line))
      .filter(Boolean);

    const uniqueEntries = [...new Set(normalizedEntries)];
    const nowIso = new Date().toISOString();

    await chrome.storage.local.set({
      [STORAGE_KEYS.PHISH_LIST]: uniqueEntries,
      [STORAGE_KEYS.LAST_UPDATE]: nowIso
    });

    phishSet = new Set(uniqueEntries);

    console.info(`[Anti-Phishing Guard] Список OpenPhish обновлён. Записей: ${uniqueEntries.length}`);
  } catch (error) {
    logError('Ошибка обновления OpenPhish', error);
  }
}

/**
 * Проверяет, выглядит ли URL подозрительно.
 * Критерии:
 * - IP в hostname,
 * - длина URL > 50,
 * - поддоменов > 3,
 * - подозрительный TLD.
 *
 * @param {string} url
 * @returns {boolean}
 */
function isSuspiciousUrl(url) {
  try {
    const parsed = new URL(url);
    const hostname = parsed.hostname.toLowerCase();
    const parts = hostname.split('.').filter(Boolean);
    const tld = parts.length > 0 ? `.${parts[parts.length - 1]}` : '';

    const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
    const hasIp = ipRegex.test(hostname);
    const isLong = url.length > 50;
    const hasTooManySubdomains = parts.length > 4;
    const suspiciousTlds = new Set(['.xyz', '.top', '.club', '.work', '.date', '.loan', '.bid']);
    const hasSuspiciousTld = suspiciousTlds.has(tld);

    return hasIp || isLong || hasTooManySubdomains || hasSuspiciousTld;
  } catch {
    return false;
  }
}

/**
 * Считает риск по эвристике.
 * Вес:
 * - password: 2
 * - externalForms: 2
 * - iframe: 1
 * - suspiciousUrl: 2
 * Бонус: +3 за сочетание password + externalForms
 *
 * @param {{password?: boolean, externalForms?: boolean, iframe?: boolean, suspiciousUrl?: boolean}} features
 * @returns {number}
 */
function calculateRiskScore(features) {
  const safeFeatures = features || {};

  let score = 0;
  if (safeFeatures.password) score += 2;
  if (safeFeatures.externalForms) score += 2;
  if (safeFeatures.iframe) score += 1;
  if (safeFeatures.suspiciousUrl) score += 2;

  if (safeFeatures.password && safeFeatures.externalForms) {
    score += 3;
  }

  return score;
}

/**
 * Возвращает статистику состояния расширения.
 */
async function getStatus() {
  const data = await chrome.storage.local.get([STORAGE_KEYS.PHISH_LIST, STORAGE_KEYS.LAST_UPDATE]);
  const list = Array.isArray(data[STORAGE_KEYS.PHISH_LIST]) ? data[STORAGE_KEYS.PHISH_LIST] : [];

  return {
    enabled: true,
    listCount: list.length,
    lastUpdate: data[STORAGE_KEYS.LAST_UPDATE] || null
  };
}

/**
 * Инициализация: загрузка кэша и установка periodic alarm.
 */
async function initialize() {
  await loadPhishSetFromStorage();

  try {
    await chrome.alarms.create(UPDATE_ALARM_NAME, {
      periodInMinutes: UPDATE_INTERVAL_MINUTES
    });
  } catch (error) {
    logError('Ошибка создания alarm', error);
  }
}

chrome.runtime.onInstalled.addListener(async () => {
  await initialize();
  await updateOpenPhishList();
});

chrome.runtime.onStartup.addListener(async () => {
  await initialize();
  await updateOpenPhishList();
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm?.name === UPDATE_ALARM_NAME) {
    await updateOpenPhishList();
  }
});

chrome.webNavigation.onBeforeNavigate.addListener(async (details) => {
  if (!details || details.frameId !== 0 || !details.url) {
    return;
  }

  try {
    const extensionWarningPrefix = chrome.runtime.getURL('warning.html');
    if (details.url.startsWith(extensionWarningPrefix)) {
      return;
    }

    const normalizedCurrent = normalizeUrl(details.url);
    if (!normalizedCurrent) {
      return;
    }

    if (phishSet.has(normalizedCurrent)) {
      const warningUrl = `${chrome.runtime.getURL('warning.html')}?url=${encodeURIComponent(details.url)}`;
      await chrome.tabs.update(details.tabId, { url: warningUrl });
    }
  } catch (error) {
    logError('Ошибка проверки webNavigation', error);
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    try {
      if (!message || !message.type) {
        sendResponse({ ok: false, error: 'Некорректное сообщение' });
        return;
      }

      if (message.type === 'PAGE_ANALYSIS') {
        const incomingFeatures = message.features || {};
        const targetUrl = typeof message.url === 'string' ? message.url : '';

        const features = {
          password: Boolean(incomingFeatures.password),
          externalForms: Boolean(incomingFeatures.externalForms),
          iframe: Boolean(incomingFeatures.iframe),
          suspiciousUrl: Boolean(incomingFeatures.suspiciousUrl) || isSuspiciousUrl(targetUrl)
        };

        const score = calculateRiskScore(features);

        if (score >= 4 && sender?.tab?.id) {
          await chrome.tabs.sendMessage(sender.tab.id, {
            type: 'SHOWSOFTWARNING',
            url: targetUrl,
            score
          });
        }

        sendResponse({ ok: true, score });
        return;
      }

      if (message.type === 'MANUAL_UPDATE' || message.type === 'MANUALUPDATE') {
        await updateOpenPhishList();
        const status = await getStatus();
        sendResponse({ ok: true, status });
        return;
      }

      if (message.type === 'GET_STATUS' || message.type === 'GETSTATUS') {
        const status = await getStatus();
        sendResponse({ ok: true, status });
        return;
      }

      sendResponse({ ok: false, error: 'Неизвестный тип сообщения' });
    } catch (error) {
      logError('Ошибка в runtime.onMessage', error);
      sendResponse({ ok: false, error: String(error) });
    }
  })();

  return true;
});

initialize().catch((error) => {
  logError('Ошибка инициализации background', error);
});